drop table if exists empenhonotacontroleinternohistorico;
drop sequence if exists empenhonotacontroleinterno_sequencial_seq;
drop table if exists empenhonotacontroleinterno;

drop table if exists plugins.liquidacaocompetencia;
drop sequence if exists plugins.liquidacaocompetencia_sequencial_seq;                                              

drop table if exists plugins.empenhonotacontroleinternohistoricousuario;
drop sequence if exists plugins.empenhonotacontroleinternousuario_sequencial_seq;
